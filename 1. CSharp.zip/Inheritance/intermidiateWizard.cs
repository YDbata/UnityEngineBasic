﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    internal class intermidiateWizard : Wizard
    {
        // 여기서는 Wizard가 Move를 재정의 하고 있기때문에 다시 Move를 만들 필요는 없다
    }
}
