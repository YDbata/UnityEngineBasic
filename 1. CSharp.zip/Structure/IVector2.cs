﻿namespace Structure
{
    public interface IVector2
    {
        float Maginitude();
    }
}